<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login ems</title>
<link rel="stylesheet"  href="custom.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
</head>
<style >

</style>
<body>

	<!--<button onclick="launch_toast()">Show Toast</button>
<?php if(isset($_GET['msg'])){?>
<div id="toast"><div id="img">Icon</div>
  <div id="desc"> <?php echo $_GET['msg'];?></div>
<?php }?>
</div> -->

<div class="content-wrapper">
	<div class="container">
		<center>
		<div class="row">
			<div class="col-md-4">
				<button type="button" class="btn btn btn-info"  data-toggle="modal" data-target="#myModal">Forget Password</button>
				<div class="form-group" id="form-group1">
					
						<form method="POST" action="checklogin.php">
							<label><strong>Choose Type *</strong></label>
							<select name="type" class="form-control">
								<center><option value="admin">Admin</option><
					        	<option value="teacher">Teacher</option>
					        	<option value="student">Student</option>
							</select>
					    	<label><strong>Username *</strong></label>
					    	<input type="text" placeholder="examlegmail.com" name="name"  class="form-control" />
					    	<label><strong>Password *</strong></label>
					    	<input type="password" name="password" class="form-control"/>
					    	<br/>
					        <input  type="submit" name="submit"  class="btn btn-success" value="Login" />
						</form>	
				</div>
			</div>
		</div>
		</center>
<?php if(isset($_GET['msg'])){?>
<div class="col-md-4">
	<div class="alert alert-success" id="error">Message:-
	<?php echo $_GET['msg'];?></div>
	<?php }?>
</div>
</div>
</div>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Enter Existing Email</h4>
        </div>
        <div class="modal-body">
          <form method="POST" action="forget.php">
          	<div class="col-md-4">
          		<label><strong>Choose Type</strong></label>
          	<select name = "type" class="form-control">
          		<option value="teacher">Teacher</option>
          		<option value="student">Student</option>
          	</select>
          </div>
          	<div class="col-md-6">
          	<label><strong>Enter Registered Email</strong></label>
          	<input type="email" name="u_email" placeholder="Example@gmail.com" class="form-control" required><br/>
          	<input type="submit" name="submit_email" class="btn btn-dark" value="Submit Email">
          </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

	<script type="text/javascript">
		function launch_toast() {
    var x = document.getElementById("toast")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 5000);
}
	</script>
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</body>
</html>