<?php
include('config.php');

if($_POST)
{
	$type = $_POST['type'];
	$username = $_POST['name'];
	$password = $_POST['password'];	 
	 
	 /*if($type == 'admin')
	 {
		$query = mysql_query("select * from tbl_admin where u_name ='$username' and admin_password = '".md5($password)."'");
		$count = mysql_num_rows($query);
		if($count == '1'){
			$row = mysql_fetch_array($query);
			$_SESSION['admin_id'] = $row['id'];
			$_SESSION['admin_name'] = $row['name'];
			print('<script>window.location="admin/dashboard.php"</script>');
			}
			else
			{
			print('<script>window.location="index.php?msg=Invalid username and password ."</script>');
			}

			}
	*/
	if($type == 'teacher')
	{
		$query=mysql_query("select * from  tbl_teacher where u_name ='$username' and password = '".md5($password)."'");
		$count = mysql_num_rows($query);
		if($count == '1'){ 
			$row = mysql_fetch_array($query);
		$st=$row['status'];
		//echo $st;
		if($st=='0')
		{
			$_SESSION['teacher_id'] = $row['id'];
			//echo $_SESSION['teacher_id'];
			//$_SESSION['teacher_sub'] = $row['subject'];
-			$_SESSION['teacher_uname'] = $row['u_name'];
			$_SESSION['teacher_year']=$row['year'];
			print('<script>window.location="teacher/add_test.php"</script>');
			}
			else
			{
				//echo $st;
				echo "you are not authorised to access this site";
			}
		}
			else
			{
			print('<script>window.location="index.php?msg=Invalid username and password ."</script>');
			}
			
	}

	if($type == 'student')
	{
	$query=mysql_query("SELECT * FROM `tbl_student` WHERE u_name='$username' and password='".md5($password)."'");
	 $count = mysql_num_rows($query);
	  if($count== '1' )
	  {
		$row=mysql_fetch_array($query);
		$st=$row['status'];
		if($st=='0')
		{
		$_SESSION['student_id']=$row['id'];
		$_SESSION['student_name']=$row['u_name'];
		//$_SESSION['class_name']=$row['class'];
		print('<script>window.location="student/test.php"</script>');
	}
	else{
		echo "you are not authorised to use this site";
	}	 
	  }
	  else
	  {
		print('<script>window.location="index.php?msg=Invalid username and password ."</script>'); 
	  }
	
	}
		
}
?>
