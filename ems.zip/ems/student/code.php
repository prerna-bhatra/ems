<?php require("../config.php"); ?>
<?php
 error_reporting(0); 
//if(isset($_GET['eid']))
//{
	
	/*while ($row=mysql_fetch_array($ans1)) {
		echo $row['right_ans']."<br>";
	}*/
	//echo $count;
	//$ans[]=$_POST['ans'];
	//echo $_POST['ans'];

//print_r($_POST['qus']);

//	$i=1;
	$eid=@$_GET['eid'];
for($i=0;$i<count($_POST['qus']); $i++)
{

$qid =  $_POST['qus'][$i];
$ansid = $_POST['ans'][$qid];
mysql_query("INSERT INTO `s_ans` (`id`, `qid`, `ans`,`sid`,`eid`) VALUES (NULL, '".$qid."', '".$ansid."','".$_SESSION['student_id']."','".@$_GET['eid']."')");
	/**/
}
$att= count($_POST['ans']);
echo "<script>window.location.href='onlinetest.php?msg=end&eid=$eid&att=$att';</script>";


	


?>