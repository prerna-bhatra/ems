<?php require("../config.php"); ?>
<!doctype html>
<html lang="en">
<head>
  <style >
  </style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Time Table</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assests/css/hover.css">
<link rel="stylesheet" href="../admin/assests/css/style.css">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#tabs" ).tabs();
  } );
  </script>
</head>
<body>
 <?php //include('header.php'); ?>
<div id="tabs">

  <ul>
    <?php 
    $query1=mysql_query("SELECT * FROM `questions` WHERE exam_id='5d2050fbeeaf2'");
    $count=mysql_num_rows($query1);
    for($i=1;$i<=$count;$i++)
    { ?>
    <li><a href="#tabs-<?php echo $i; ?>"><?php echo $i; ?></a></li>
    <?php } ?>

  </ul>
  <?php 
  
    $j=0;
  while($row1=mysql_fetch_array($query1))
  {
    $j++;
?>
  <div id="tabs-<?php echo $j; ?>">
  
  	<?php
  	?>
  	<table class="table-bordered table table-striped">
  		<thead>
  			<tr>
  				<td>Time</td>
  				<td>Subject,Teacher</td>
  			</tr>
  		</thead>
  	<?php 
    //$class_name1=$_SESSION['class_name'];
    //echo $class_name1;
  	
   // echo $row1['time'];
    ?>
  	

  		<tr>
  			<td><?php echo $row1['id']?></td>
  			<td><?php echo $row1['que']?></td>
        <?php for($k=0;$k<5;$k++){
          ?>
          <input type="radio" name="">
          <?php
        } ?>
  		</tr>

  </table>
      </div>
   <?php } ?>
</div>
 
 
</body>
</html>
