<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
    <form action="phpjs.php" method="post">
       <input type="submit" name="hello" value="hello">
       <input type="submit" name="goodBye" value="goodBye">
    </form>
    <article>
       <?php
           if (isset($_POST['hello'])) {
               echo "This happens if you click hello";
           }
           if (isset($_POST['goodBye'])) {
               echo "This happens if you click goodBye";
           }
        ?>
     </article>
</body>
</html>