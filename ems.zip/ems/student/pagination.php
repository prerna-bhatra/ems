<?php require("../config.php"); ?> 
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
<script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.0.3.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="dist/simplePagination.css" />
<script src="dist/jquery.simplePagination.js"></script>
</head>
<body>
  <?php  
  		$limit = 1;  
		if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };  
		$start_from = ($page-1) * $limit;  
		$sql = mysql_query("SELECT * FROM questions ORDER BY id ASC LIMIT $start_from, $limit");  
		//$rs_result = mysqli_query($conn, $sql);
        //$sql="SELECT * FROM `questions` ";  
       // $rs_result = mysqli_query($conn, $sql);  
		//echo $sql;
        //$row = mysql_fetch_array($sql); 
        //echo $total_records = $row[0];  
       //echo $total_pages = ceil($total_records / $limit);  
        $pagLink = "<nav><ul class='pagination'>";  
        for ($i=1;$i<=4; $i++) { 

                     $pagLink .= "<li><a href='pagination.php?page=".$i."'>".$i."</a></li>";  
        };  
        echo $pagLink . "</ul></nav>";  
        ?>
         <table class="table table-bordered">  
        <thead>  
        <tr>  
        <th>Name</th>  
        <th>Salary</th>
        <th>Age</th>  
        </tr>  
        </thead>  
        <tbody>  
        <?php  
        while ($row = mysql_fetch_array($sql)) {
        ?>  
                    <tr>  
                    <td><?php echo $row["id"]; ?></td>  
                    <td><?php echo $row["que"]; ?></td>  
                    <td><?php echo $row["exam_id"]; ?></td>  
                    </tr>  
        <?php  
        };  
        ?>  
        </tbody>  
        </table>
          
        <script type="text/javascript">
            $(document).ready(function(){
            $('.pagination').pagination({
                    items: <?php echo $total_records;?>,
                    itemsOnPage: <?php echo $limit;?>,
                    cssStyle: 'light-theme',
                    currentPage : <?php echo $page;?>,
                    hrefTextPrefix : 'index.php?page='
                });
                });
            </script>
</body>
</html>