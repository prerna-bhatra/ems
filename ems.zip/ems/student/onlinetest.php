<?php require("../config.php"); ?>
<!doctype html>
<html lang="en">
<head>
  <style >
  </style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Prerna Bhatra</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  
</head>
<style type="text/css">
 
 .result
 {
  margin-top: 100px;
  box-shadow: 0px 0px 5px 3px;
  padding: 5px 5px 5px 5px;
 }
 #head
 {
  color: red;
  background: rgba(0,0,0,0.3);
  text-align: center;

 }
 .det
 {
  border-bottom: 1px solid black;
  padding-left: 300px;
 }
 #det
 {
  color: red;
 }
 #icon
 {
  font-size: 100px;
 }
.duration
{
  border: 1px solid black;
  padding: 2px 10px 10px 10px;
  margin-bottom:2px;
  background: #00FF00;
  box-shadow:2px 2px 2px 0px rgba(0,0,0,0.3);
   position: fixed;
  top: 0;
  width: 100%;
  z-index: 999;
}
.duration #task
{
  color: red;
}
.duration h3
{
  color: blue;
}
#panel{

  padding-left:20px;
  margin-bottom: 200px;
  position: relative;
  margin-top: 97px;

}
#btn
{
  background: green;
   color: white;
   
}
.btn1
{
  background-color:black;
  color: white;
  padding:5px 5px 5px 5px;
}
.panel-footer
{
  text-align: center;

}
@media (max-width:768px)
{
  .det
  { padding-left:0; }
   #icon
 {
  font-size: 20px;
 }
 .res
 {
  text-align: center;
 } 
  .result
 {
  margin-top: 0px;
  box-shadow: 0px 0px 5px 3px;
 }



}
</style>
<body  >
 
        <?php 

        $student_id1=$_SESSION['student_id'];
        $exam_id=@$_GET['eid'];
        $sessiovar=0;
        $r=mysql_query("SELECT * FROM `s_result` WHERE sid='$student_id1' and eid='$exam_id'");
        $count=mysql_num_rows($r);
        if($count!=1)
        {
        if(isset($_GET['eid'])&&!isset($_GET['msg'])) {?>
        <?php  
        session_start();
 
        if(isset($_SESSION['test']))
 
         $_SESSION['views'] = $_SESSION['views']+1;
        else
        {
          $_SESSION['test']=$exam_id;
          $_SESSION['views']=1;
        // echo"views = ".$_SESSION['views'];
         } 
         if($_SESSION['views']>='2')
         {
          $sessiovar=1;
         }

            $eid=@$_GET['eid'];
                //echo $eid;
            $q=mysql_query("SELECT * FROM `exams` WHERE id='$eid'");
            $row=mysql_fetch_array($q);
           // $dur=;
            //echo $dur;
        //echo $row['id'];
        ?>
        <div class="duration">
          <div class="row">
            <div class="col-md-8 col-xs-4">
          <h4><i class="fa fa-clock-o"></i>Time Remaining</h4><h4 id="dur"></h4>
        </div>
        <div class="col-md-4 col-xs-6">
          <h3><i class="fa fa-tasks" id="task"></i>&nbsp; Test name-:<?php 
            echo $row['testname']; //echo"views = ".$_SESSION['views']; echo  $sessiovar;
        
            ?></h3>
          
        </div>
        </div>
        </div>
         <div class="container">
        <div class="panel panel-success" id="panel">
          <div class="panel-body">
            <h3>Questions</h3>
            <?php
            $i=1;
            $j=0;
            $k=1000;
            $l=2000;
            $m=3000;
            $qns=mysql_query("SELECT * FROM `questions` WHERE exam_id='".$eid."'"); 
              ?>
              <div class="card
              ">
              <form action="code.php?eid=<?php echo $eid; ?>" method="POST">
                <?php  
                  while ($row1=mysql_fetch_array($qns)) {
                   ?><h4><?php echo "(".$i++.")&nbsp".$row1['que'];?></h4>
                    <input type="hidden" name="qus[]"  value="<?php echo $row1['id'] ?>">
                    <input type="radio" id="<?php echo $j;  ?>" name="ans[<?php echo $row1['id'] ?>]" value="1">&nbsp;&nbsp;<?php echo $row1['option1']."<br>" ?>
                    <input type="radio" id="<?php echo $k; ?>" name="ans[<?php echo $row1['id'] ?>]" value="2">&nbsp;&nbsp;<?php echo $row1['option2']."<br>" ?>
                    <input type="radio" id="<?php echo $l;  ?>" name="ans[<?php echo $row1['id'] ?>]" value="3">&nbsp;&nbsp;<?php echo $row1['option3']."<br>" ?>
                    <input type="radio" id="<?php echo $m;  ?>" name="ans[<?php echo $row1['id'] ?>]" value="4">&nbsp;&nbsp;<?php echo $row1['option4']."<br>" ?>
                    <input type="button"  onclick="document.getElementById('<?php echo $j++; ?>').checked=false;document.getElementById('<?php echo $k++ ?>').checked=false;document.getElementById('<?php echo $l++; ?>').checked=false;document.getElementById('<?php echo $m++; ?>').checked=false; "class="btn1" value="Clear Response" >
                    <?php
                  }


                  /*if($sessiovar=='1')
                 {
                    echo '<script language="javascript">';
                    echo 'javscript: document.getElementById("btn").click();';
                    echo '</script>';  
                   }*/
                ?>
                <div class="panel-footer">
                <input type="submit" name="submit" value="End Test" class="btn btn-lg" id="btn">
              </div>
              </form>
            </div>
          </div>
              <?php
            }
            elseif (isset($_GET['eid'])&&isset($_GET['msg'])) {
              # code...
              $att=@$_GET['att'];
              $marks=0;
              $j=0;

                $eid=@$_GET['eid'];
                $test=mysql_query("SELECT * FROM exams WHERE id='$eid'");
                $rowe=mysql_fetch_array($test);
                $m=$rowe['right_ans'];
                $n=$rowe['worng_ans'];
               /* echo $m;
                echo "<br>".$n;*/
                $ans1=mysql_query("SELECT * FROM `questions` WHERE exam_id='$eid' ");
                $count1=mysql_num_rows($ans1);
                //echo $count1;
                while ($row=mysql_fetch_array($ans1)) 
                {
                  $sid=$_SESSION['student_id'];
                   $qid=$row['id'];
                  $ans2=mysql_query("SELECT * FROM `s_ans` WHERE eid='$eid' and sid='$sid' and qid='$qid'");
                  $row1=mysql_fetch_array($ans2);
                  /*echo $row1['ans']."&nbsp";
                  echo $row['right_ans']."<br>";
                /*$count=mysql_num_rows($ans2);
                echo $count; */
                if ($row1['ans']==$row['right_ans']) {
                  $marks=$marks+$m;
                  $j++;
                }
                elseif($row1['ans']=='0')
                {
                  $marks=$marks;
                }
                else {
                  $marks=$marks-$n;
                }

                
                }
                ?>
                <div class="result">
                  <h1 id="head">Result</h1>
                  <?php session_destroy(); ?>
                  <a href="../index.php" class="btn btn btn-info">Back</a>
                  <div class="det">
                  <h4>User Name:<span id="det"><?php echo $_SESSION['student_name'] ?></span></h4>
                  <h4>Test Name:<span id="det"><?php echo $rowe['testname'] ?></span></h4>
                  <h4>Login Id: <span id="det"><?php echo $_SESSION['student_id'] ?></span></h4>
                 </div>
                 <div class="res">
                      <h3>Your Score</h3>
                      <div class="row">
                        <div class="col-md-3 col-xs-6">
                      <i class="fa fa-question" id="icon"></i><h4>Total Questions: <?php echo $count1 ; ?>
                        </h4></div>
                        <div class="col-md-3 col-xs-6">
                      <i class="fa fa-pencil" id="icon"></i><h4>Total Attempt: <?php echo $att; ?>
                        </h4></div>
                        <div class="col-md-3 col-xs-6">
                       <i class="fa fa-check"  id="icon"></i><h4>Correct: <?php echo $j; ?></h4>
                     </div>
                     <div class="col-md-3 col-xs-6">
                       <i class="fa fa-tasks"  id="icon"></i><h4>Marks: <?php echo $marks; ?></h4>
                     </div>
                     </div>
                  </div>
           <?php 
           $q=mysql_query("INSERT INTO `s_result`(`id`, `sid`, `t_att`, `corr`, `marks`, `date`,`ename`, `eid`) VALUES (NULL,'".$_SESSION['student_id']."','".$att."','".$j."','".$marks."','".date('Y-m-d')."','".$rowe['testname']."','".$eid."')");
         }
           
           } 
           else
            {
              echo "<script>
          alert('Test Alredy Attempted');
          window.location.href='test.php?action=attempt';
          </script>";
            }?>  
                
        </div>
</div>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
var sess=<?php echo $sessiovar; ?>;
var min=<?php echo $row['duration'] ?>;
var sec = 60;
/* Website to redirect */
var url = "code.php?msg=result";
/* Call function at specific intervals */
var countdown = setInterval(function() { 
    /* Display Countdown with txt */
if(sec<=0)
{
  var min1=min--;
  sec=sec+60;
}
var mini=1;
$(document).mouseleave(function ()
{
   swal({
        title: "warning",
        text: "Test will auto submitted!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: 'btn-danger',
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: "No, cancel plx!",
        closeOnConfirm: false,
        closeOnCancel: false
        });
   mini++;
   if(mini==5)
   {
    sess=1;
   }
  
});
    
document.getElementById("dur").innerHTML =
min + "\t:" + (sec--) + "<br>";
    /* If count is smaller than 0 ...*/
    if (min<=0 || sess==1) {
        document.getElementById("btn").click();
        /* Clear timer set with setInterval */
        //clearInterval(countdown);
        /* Redirect */
        alert("Test Ended and Auto submitted ");
        //$(location).attr("href", url);
   } 
    // milliseconds
}, 1000);
</script>
<!--<script>
// Warning before leaving the page (back button, or outgoinglink)
window.onbeforeunload = function() {
   return "Do you really want to leave our brilliant application?";
   //if we return nothing here (just calling return;) then there will be no pop-up question at all
   //return;
};
</script>-->
</body>
</html>
