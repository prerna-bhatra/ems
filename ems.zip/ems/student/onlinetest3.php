<?php require("../config.php"); ?>
<?php// if(!isset($_SESSION['admin_id'])) { header("location:index.php"); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Online Test</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assests/css/hover.css">
<link rel="stylesheet" href="../admin/assests/css/style.css">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
<link rel="stylesheet" href="assests/css/hover.css">
<link rel="stylesheet" href="assests/css/style.css">
<link rel="stylesheet" href="assests/css/font-awesome.min.css"> 
</head>
<style> 
#panel, #flip {
    text-align: center;
    border: solid 1px #c3c3c3;
}

#panel {
    display: none;
}
 ul
{
	list-style: none;
}
ul li
{
	display: inline;
	
}
.questions_pointer
{
	width: 300px;
	border:1px solid black;
	height: 300px;
	overflow: scroll;
}
.questions_pointer
 ul
{
	list-style: none;
} 
.questions_pointer ul li
{
	display: inline;
	/*padding: 10px 10px 10px 10px;
	border:1px solid black;*/
	margin-top: 20px;
	margin-bottom: 20px;
	padding-bottom: 10px;

}
.questions_pointer ul li a
{   
	margin-bottom: 3px;
	margin-top: 4px;
	
}
.questions
{
	margin-top: 20px;
}
</style>
<body>
<?php include('header.php'); ?>         
<div class="content-wrapper">
	<?php 
	if(isset($_GET['eid']))
	{
	$eid=@$_GET['eid'];
	$q=mysql_query("SELECT * FROM `exams` WHERE id='$eid'  ");
	$row=mysql_fetch_array($q);
	$dur=$row['duration'];
	//echo $dur;
	//echo $row['id'];
	?>
	<div class="duration">
		<h4>Time</h4><p id="dur"></p>
	</div>
	<div >
		<center><i class="fa fa-tasks"></i>
		<h5>Test name-:<?php echo $row['testname'] ?></h5>
		</center>
		

		
		 <?php } ?>
</div>

      
	
		
<script>  
 $(document).ready(function(){  
      $('#employee_data').DataTable();  
 }); 
 
 </script> 
 
<script> 
$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
});
</script>
<script>
var min=60;
var sec = 60;
/* Website to redirect */
var url = "onlinetest.php?msg=result";
/* Call function at specific intervals */
var countdown = setInterval(function() { 
    /* Display Countdown with txt */
if(sec<=0)
{
	var min1=min--;
	sec=sec+60;
}
    
document.getElementById("dur").innerHTML =
min + "\t:" + (sec--) + "<br>";
    /* If count is smaller than 0 ...*/
    if (min <=0) {
 		
        /* Clear timer set with setInterval */
        clearInterval(countdown);
        /* Redirect */
        alert("Test Ended")
        $(location).attr("href", url);
   } 
    // milliseconds
}, 1000);
</script>
</body>
</html>