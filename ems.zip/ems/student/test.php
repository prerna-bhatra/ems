<?php require("../config.php"); ?>
<?php// if(!isset($_SESSION['admin_id'])) { header("location:index.php"); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Test</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" href="assests/css/hover.css">
<link rel="stylesheet" href="assests/css/style.css">
<link rel="stylesheet" href="assests/css/font-awesome.min.css"> 
</head>
<style> 
#panel, #flip {
    text-align: center;
    border: solid 1px #c3c3c3;
}

#panel {
    display: none;
}
.cb
{
	border-radius: 4px;
}
.duration
{
	text-align: right;
}
</style>
<body>
<?php include('header.php'); ?>
            
<div class="content-wrapper">
	<a href="test.php?action=attempt" class="btn btn-dark">Attempt Test</a> 
	<a href="test.php?action=res" class="btn btn-primary">Result</a>  
<?php 
if(@$_GET['action']=='attempt')
{
	
	?>
	<div class="table-responsive">
<table class="table table-bordered table-striped" id="order-listing" style="width:100% ">
	<thead>
		<td>Test Name</td>
		<td>Action</td>
	</thead>
	<tbody>
		<?php  
		$q=mysql_query("SELECT * FROM `exams`");
		while ($row=mysql_fetch_array($q)) {
			?>
			<tr>
			<td><?php echo $row['testname']; ?></td>
			<td><a href="onlinetest.php?eid=<?php echo $row['id'] ?>"><i class="fa fa-tasks" ></i></a></td>
		</tr>
			<?php
		}
		?>
	</tbody>
</table>
</div>
	<?php
}
elseif (@$_GET['action']=='res')
 {
		//echo "string";
 		$sid=$_SESSION['student_id'];
 		$r=mysql_query("SELECT * FROM `s_result`  WHERE sid='$sid'");
 		?>
 		<div class="table-responsive">
 		<table class="table table-bordered table-striped" id="order-listing" style="width: 100%;">
 			<thead>
 				<td>Test Name</td>
 				<td>Attempt Que</td>
 				<td>Correct</td>
 				<td>Marks</td>
 				<td>Date</td>
 				
 			</thead>
 			<tbody>
 		<?php
 		while ($row=mysql_fetch_array($r)) 
 		{
 			?>
 			<tr>
 				<td><?php echo $row['ename'] ?></td>
 				<td><?php echo $row['t_att'] ?></td>
 				<td><?php echo $row['corr'] ?></td>
 				<td><?php echo $row['marks'] ?></td>
 				<td><?php echo $row['date'] ?></td>
 			</tr>
 			<?php
 		}
 		?>
 	</tbody>
 		</table>
 	</div>
 		<?php
}
?>
</div>    
<script src="assests/js/jquery.js"></script>
<script src="assests/js/script.js"></script>
<script src="assests/data-table/jquery.dataTables.min.js"></script>
<script src="assests/data-table/dataTables.bootstrap4.min.js"></script>
<script src="assests/data-table/dataTables.responsive.min.js"></script>

<script>  
 $(document).ready(function(){  
      $('#employee_data').DataTable();  
 }); 
 
 </script> 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script> 
$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
});
</script>

</script>
 </body>
</html>