<?php require("../config.php"); ?>
<?php
require('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet"  href="custom.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
</head>
<div class="container">
    <?php  
    $s_rd=(rand(1000,9999));
    $_SESSION['$random']=$s_rd;
    $type=$_POST['type'];
    $_SESSION['type_u']=$type;
    $email=$_POST['u_email']; ?>
 <?php 
      
        if(isset($_POST['submit_email']))
        {
            $email1=$_POST['u_email'];
            if($type == 'teacher')
            {
                    
                  $query=mysql_query("SELECT * FROM `tbl_teachers` where teacher_email='$email'");
                      $row=mysql_fetch_array($query);
                     $_SESSION['teacher_email']=$row['teacher_email'];
            }
            elseif($type == 'student')
            {
                    $query=mysql_query("SELECT * FROM `tbl_students` WHERE student_email='$email'");
                      $row=mysql_fetch_array($query);
                     $_SESSION['student_email']=$row['student_email'];
            }
                $no = mysql_num_rows($query);
                if($no == '1')
                {
                ?>
                <div class="row">
                <div class="col-md-4">
                    <?php 
                    $random=$_SESSION['$random'];
                    $user_email=$_POST['u_email'];
                    mail("$user_email", "otp for change password", $random);
                    echo "Mail has been sent to";
                    echo "<br>";
                    echo $_POST['u_email'];
                    echo "<br>";
                    echo "OTP";
                     echo "<br>";
                    echo $_SESSION['$random'];
         ?>
            <form  method="POST" action="forgetpassword.php">
                <label><strong>One Time Password</strong></label>
                <input type="text" name="otp" placeholder="4 digit number" class="form-control">
                <br/>
                <input type="submit" name="submit_otp" placeholder="Done"  class="btn btn-dark" >
            </form>
            <!--<script type="text/javascript"> //window.location = "index.php";</script>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/yLI2k4Ffc8M" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
        </div>
        </div>

                <?php
                }else{
                    print('<script>window:location="index.php?msg=Email does not exist"</script>');
                }

        	// $email1=$_POST['u_email'];
        	// $query1=mysql_query("SELECT * FROM `tbl_students` WHERE student_email='$email1'");
         //    $row1=mysql_fetch_array($query1);
         //    $s_id=$row1['student_id'];
        	// $coutn1=mysql_num_rows($query1);
        	// $query2=mysql_query("SELECT * FROM `tbl_teachers`  WHERE teacher_email='$email1' ");
        	// $coutn2=mysql_num_rows($query2);
         //     $row2=mysql_fetch_array($query2);
         //    $t_id=$row2['id'];
        	// if($coutn1=='1')
        	// {
                
         //        mail("$email1","your otp for student forget password is ",$s_rd);
         //        echo "mail has been sent to  <br> Please enter opt within 5 minutes after 5 minutes you will be redircted to login page(student)<br>";
         //        echo $_POST['u_email'];
         //        $_SESSION['u_otp']=$s_rd;
         //        $_SESSION['s_email']=$row1['student_email'];
         //        //$_SESSION['sid']=  $s_id;
        	// 	echo $s_rd;
        	// }
        	// elseif($coutn2=='1') {
         //        //$t_rd=(rand(1000,9999));
         //        mail("$email1","your otp for student forget password is ",$s_rd);
         //        echo "mail has been sent to  <br> Please enter opt within 5 minutes after 5 minutes you will be redircted to login page(teacher)<br>";
         //        echo $_POST['u_email'];
         //        $_SESSION['u_otp']=$s_rd;
         //        $_SESSION['t_email']=$row2['teacher_email'];
         //        // $_SESSION['tid']=  $t_id;
         //        echo $s_rd;
        	// }
         //    else
         //    {
         //        echo "email does not exitts";
         //    }

        }
        else
        {

        }

         ?>
        
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
      setTimeout(function() {
       window.location.href = "index.php"
      }, 50000);
    });
</script>