<?php require("config.php"); ?>
<?php// if(!isset($_SESSION['admin_id'])) { header("location:index.php"); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Teacher Dashboard</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" href="assests/css/hover.css">
<link rel="stylesheet" href="assests/css/style.css">
<link rel="stylesheet" href="assests/css/font-awesome.min.css"> 
</head>
<style> 
#panel, #flip {
    text-align: center;
    border: solid 1px #c3c3c3;
}

#panel {
    display: none;
}
./*col-md-offset-3
{
	background: white;
	box-shadow: 1px 1px 8px 2px;
	padding-top: 20px;
	overflow:scroll;
	height: 600px;
}
</style>
<body>
<?php include('header.php'); ?>
          
<div class="content-wrapper">
 	<div class="container">
 		<div class="row">
 			<div class="col-xs-12">
		 		<a href="add_test.php?msg=add_new_test" class="btn btn-dark btn-xs">Add  Test</a>
		 		<a href="add_test.php?msg=del_test" class="btn btn-danger btn-xs">Delete Test</a>
		 		<a href="add_test.php?msg=res" class="btn btn-success btn-xs">Result</a>
	 		</div>
 		</div>
 		<?php 
 		if(@$_GET['msg']=='add_new_test')
 		{
 		if(@$_GET['q']!=1 && !(@$_GET['step']) ) {
 ?>
 		<form action="code.php?q=addtest" method="POST">
 			<div class="row">
 				<input type="hidden" name="action" value="add_test">
 				<div class="col-md-offset-3 col-md-6 ">
 					<div class="form-group">
		 				<input type="text" name="test_name" placeholder="Enter Test Name" class="form-control">
		 			</div>
		 			<div class="form-group">
		 				<input type="number" name="num_que" placeholder="Enter Toatal Number of Questions" class="form-control">
		 			</div>
		 			<div class="form-group">
		 				<input type="number" name="num_per_que" placeholder="Enter marks for right answer" class="form-control">
		 			</div>
		 			<div class="form-group">
		 				<input type="number" name="neg_per_que" placeholder="Enter neg marks for wrong answer" class="form-control">
		 			</div>
		 			<div class="form-group">
		 				<input type="number" name="time_limit" placeholder="Enter time limit for test in minutes" class="form-control">
		 			</div>
		 			<div class="form-group">
		 				<input type="submit" name="submit_test" class="btn btn-dark" value="Done">
		 			</div>
		 		</div>
 			</div>
 		</form>
 		<?php 
 	}
 }
 		if(@$_GET['q']==1&&(@$_GET['step'])==2 ) 
 		{	

 			$eid=@$_GET['eid'];
 				$t=@$_GET['n'];

 			//echo $eid;
 			//echo $t;
 			?>
 			<form method="POST" action="code.php?n=<?php echo @$_GET['n']; ?>&eid=<?php  echo $eid?>"> 
 				<input type="hidden" name="action" value="add_que">
 				<div class="row">
 				<div class="col-md-offset-3 col-md-6">
 			<?php
 			for($i=1;$i<=$t;$i++)
 			{	
 				?>
 				<div class="form-group">
 				<input type="textarea" name="que[]" class="form-control" placeholder="Question<?php echo $i; ?>">
 				</div>
 				<div>
 					<div class="row">
 					<div class="col-md-6">
 						<div class="form-group">
 						<input type="text" name="opt1[]" placeholder="option a" class="form-control">
 						</div>
 					</div>
 				</div>
 				<div class="row">
 					<div class="col-md-6">
 						<div class="form-group">
 						<input type="text" name="opt2[]" placeholder="option b" class="form-control">
 						</div>
 					</div>
 				</div>
 				<div class="row">
 					<div class="col-md-6">
 						<div class="form-group">
 						<input type="text" name="opt3[]" placeholder="option c" class="form-control">
 						</div>
 					</div>
 				</div>
 				<div class="row">
 					<div class="col-md-6">
 						<div class="form-group">
 						<input type="text" name="opt4[]" placeholder="option d" class="form-control">
 						</div>
 					</div>
 				</div>
 				<div class="row">
 					<div class="col-md-6">
 						<label>Choose Correct Ans for Que <?php echo $i; ?></label>
 						<div class="form-group">
 							<select class="form-control" name="ans[]">
 								<option value="1">Option a</option>
 								<option value="2">Option b</option>
 								<option value="3">Option c</option>
 								<option value="4">Option d</option>
 							</select>
 						</div>
 					</div>
 				</div>
 					
 				</div>
			<?php

 			}
 			?>
 			</div>
 				</div>
 			<div class="row">
 					<div class="col-md-offset-8">
 				<input type="submit" name="submit_que" value="Submit Questions" class="btn btn-dark" >
 			</div>
 			</div>	
 			</form>
 			<?php
 		
 		
 	}
 		?>

 		<?php 
 		if(@$_GET['msg']=='del_test')
 		{
 			?>
 			<div class="table-responsive">
 			<table class="table table-bordered table-striped  " id="order-listing" style="width:100% ">
 			<thead>
 				<td style="width:10% ">Test Id</td>
 				<td style="width:20% ">Test Name</td>
 				<td style="width:10% ">Action</td>		
 			</thead>
 			<tbody>
 			<?php
 			$query=mysql_query("SELECT * FROM `exams` ");
 			while ($row=mysql_fetch_array($query)) {
 			  ?>
 			  <tr>
 			  	<td><?php echo $row['id']; ?></td>
 			  	<td><?php echo $row['testname'];?></td>
 			  	<td><a href="code.php?action=del_test_1&eid='<?php echo $row['id']; ?>'"><i  class="fa fa-trash"></i></a></td>
 			  </tr>
 			  <?php

 			}
 		}
 		?>
 	</tbody>
 		</table>
 	</div>
 		<?php if(@$_GET['msg']=='res')

 		{
 			$r=mysql_query("SELECT * FROM `s_result`");
 			?>
 			<div class="table-responsive">
 			<table class="table table-bordered table-striped " id="order-listing" style="width: 100%;">
 				<thead>
 					<td>Student Id</td>
 					<td>Test Name</td>
 					<td>Total Attempts</td>
 					<td>Correcr</td>
 					<td>Marks</td>
 					<td>Date</td>
 					
 				</thead>
 				<tbody>
 			<?php
 			while ($row=mysql_fetch_array($r)) 
 			{
 				
 				?>

 				<tr>
 					<td><?php echo $row['sid']; ?></td>
 					<td><?php echo $row['ename']; ?></td>
 					<td><?php echo $row['t_att'] ?></td>
 					<td><?php echo $row['corr']; ?></td>
 					<td><?php echo $row['marks']; ?></td>
 					<td><?php echo $row['date']; ?></td>
 					
 				</tr>
 			<?php }
 		} 
 		?>
 	</tbody>
 	</table>
 </div>
 	</div>
</div>   
<script src="assests/js/jquery.js"></script>
<script src="assests/js/script.js"></script>
<script src="assests/data-table/jquery.dataTables.min.js"></script>
<script src="assests/data-table/dataTables.bootstrap4.min.js"></script>
<script src="assests/data-table/dataTables.responsive.min.js"></script>

<script>  
 $(document).ready(function(){  
      $('#employee_data').DataTable();  
 }); 
 
 </script> 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script> 
$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
});
</script>



 </body>
</html>